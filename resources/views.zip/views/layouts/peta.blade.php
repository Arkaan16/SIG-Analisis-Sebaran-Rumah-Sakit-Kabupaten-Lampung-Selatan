<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Peta')</title>
    <link rel="icon" href="/assets/img/logol.png" type="image/png">
    @vite('resources/css/app.css')
    <!-- Menyertakan Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://cdn.jsdelivr.net/npm/@turf/turf"></script>

    <!-- Tailwind -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css?family=Karla:400,700&display=swap');
        .font-family-karla { font-family: karla; }
        .bg-sidebar { background: #3d68ff; }
        .cta-btn { color: #3d68ff; }
        .upgrade-btn { background: #1947ee; }
        .upgrade-btn:hover { background: #0038fd; }
        .active-nav-link { background: #1947ee; }
        .nav-item:hover { background: #1947ee; }
        .account-link:hover { background: #3d68ff; }
        /* Style khusus untuk tampilan mobile */
/* Style khusus untuk tampilan mobile */
@media (max-width: 640px) {
    #sidebar {
        display: none; /* Secara default sidebar tersembunyi pada mobile */
        position: fixed; /* Menggunakan fixed agar sidebar tetap di posisi kiri atas layar */
        top: 0;
        left: 0;
        z-index: 9999; /* Pastikan sidebar berada di atas elemen lainnya */
        width: 250px; /* Lebar sidebar pada mobile */
        height: 100%;
        background-color: #3d68ff; /* Warna sidebar */
    }

    #sidebar.show {
        display: block; /* Sidebar ditampilkan ketika tombol hamburger ditekan */
    }
}

/* Pastikan tombol hamburger berada di atas */
.sm:hidden {
    z-index: 10000; /* Z-index lebih tinggi untuk tombol hamburger */
}

/* Untuk memastikan bahwa sidebar dan konten memiliki transisi yang mulus */
.transition-all {
    transition: all 0.3s ease;
}

    </style>
</head>
<body class="bg-gray-100 font-family-karla">
    @yield('content') <!-- Konten halaman yang sedang aktif -->
    
    <!-- AlpineJS -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
    <!-- Font Awesome -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js" integrity="sha256-KzZiKy0DWYsnwMF+X1DvQngQ2/FxF7MF3Ff72XcpuPs=" crossorigin="anonymous"></script>
    <!-- ChartJS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js" integrity="sha256-R4pqcOYV8lt7snxMQO/HSbVCFRPMdrhAFMH+vr9giYI=" crossorigin="anonymous"></script>

</body>
</html>
