<footer class="bg-sky-700 text-white py-8 border-t border-white">
    <div class="container mx-auto text-center">
        <p>&copy; 2024 SIGLampungSelatan. Semua hak dilindungi.</p>
    </div>
</footer>